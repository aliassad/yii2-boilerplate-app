<?php
/**
 * Created by PhpStorm.
 * User: zein
 * Date: 7/6/14
 * Time: 1:53 PM
 */

namespace common\components\log;

use yii\log\Target;

class NotFoundTarget extends Target
{

    /**
     * Exports log [[messages]] to a specific destination.
     * Child classes must implement this method.
     */
    public function export()
    {
        // TODO: Implement export() method.
    }
}
