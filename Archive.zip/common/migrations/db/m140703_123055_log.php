<?php
require(Yii::getAlias('@yii/log/migrations/m141106_185632_log_init.php'));

class m140703_123055_log extends m141106_185632_log_init
{

}
